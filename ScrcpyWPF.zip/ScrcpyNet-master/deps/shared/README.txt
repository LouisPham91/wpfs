Based on scrcpy, which can be found here -> https://github.com/Genymobile/scrcpy

Binaries downloaded from https://github.com/Genymobile/scrcpy/releases/tag/v1.23
