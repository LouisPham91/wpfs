using ReactiveUI;

namespace ScrcpyNet.Sample.ViewModels
{
    public class ViewModelBase : ReactiveObject
    {
    }
}
